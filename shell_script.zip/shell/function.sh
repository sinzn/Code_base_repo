#!/bin/bash

function create_user(){
	read -p "Enter username : " username 
	sudo useradd -m $username 
}

function verify_user() {
	if  [ $(getent passwd $username ) ]; then
		echo  "user verified "
	else 
		echo "user not verified"
	fi
}

function show_disk(){
	$(df -h | awk "NR == 2 {print $2}")
}

show_disk
create_user
verify_user
