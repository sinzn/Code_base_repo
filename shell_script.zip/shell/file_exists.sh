#!/bin/bash
read -p "Enter file path : " filepath
if [ -f  $filepath ]; then
	echo "file exists"
else 
	echo "file doesn't exists"
fi
