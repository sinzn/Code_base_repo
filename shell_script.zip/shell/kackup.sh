#!/bin/bash
SOURCE="/home/cloudshell-user/shell/scripts"
TARGET="/home/cloudshell-user/shell/backup"
FILENAME="$TARGET/backup_$(date +%Y%m%d%H%M%S).tar.gz"

echo "Creating backup: $FILENAME"

tar -czf "$FILENAME" "$SOURCE" 2>/dev/null \
     && echo "Backup Created Successfully" \
         || { echo "Backup not complete"; exit 1; }
