#!/bin/bash
source_dir="/home/cloudshell-user/shell/scripts" 
backup_dir="/home/cloudshell-user/shell/backup" 
timestamp=$(date +%Y%m%d_%H%M%S) 
backup_file="$backup_dir/backup_$timestamp.tar.gz"
tar -czf $backup_file -C $source_dir
echo "Backup completed: $backup_file"
