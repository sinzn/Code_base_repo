#!/bin/bash

# comments all suppose to be inore

<<comment
this 
is 
a
multiline
commands

usage of argument is ./arguments.sh sangetta krishna 

./shell.sh $1 $2
 
comment


echo "This is first argument : $1"
echo "This is Second argument : $2"
