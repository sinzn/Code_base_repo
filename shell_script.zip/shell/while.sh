#!/bin/bash
i=0
while [ $i -le 10 ]; do
	echo "this is less than $i"
	i=$((i+1))

done
