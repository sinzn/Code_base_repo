#!/bin/bash
for i in {1..100}; do
	rmdir day-$i
done
