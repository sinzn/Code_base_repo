#!/bin/bash

for i in {1..100};do
	touch file_$i
	echo "This is file_$i" > file_$i
done
