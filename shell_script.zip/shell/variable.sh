#!/bin/bash
name="Shivam"
read -p "enter your name : " name 
echo "Hello $name"
echo "My logged in username : $USER"
echo "Today date : $(date)"
