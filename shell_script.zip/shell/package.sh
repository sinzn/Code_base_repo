#!/bin/bash

echo "Installing $1"

sudo apt-get instal $1

echo "successfully installed $1"

sudo systemctl status $1
