#!/bin/bash

echo "Hello from shell script !"

echo "Hello from shell script line numbber 2"
