#!/bin/bash
for i in {1..90}; do
	mkdir day-$i
done
