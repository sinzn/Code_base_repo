#!/bin/bash
for i in {1..100};do 
	mkdir -p day_$i
done

