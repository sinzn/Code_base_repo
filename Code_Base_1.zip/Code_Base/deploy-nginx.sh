sudo apt update -y && sudo apt upgrade -y 
sudo apt install nginx -y
sudo systemctl start nginx 
sudo systemctl enable nginx 
sudo echo '<body style="background-color:blue; color:white;"><center>Blue Server <br>Blue server ip '"$(curl -s ipinfo.io/ip)"'</center></body>' >> index.html
sudo rm -rf /var/www/html/index*
sudo mv index.html /var/www/html/
sudo systemctl restart nginx 
echo "Deployment complete :)"
