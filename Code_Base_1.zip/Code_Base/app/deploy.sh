docker build -t ecsapp:v2 .
docker run --rm -d -p 3000:3000 --name ecsappv2 ecsapp:v2
