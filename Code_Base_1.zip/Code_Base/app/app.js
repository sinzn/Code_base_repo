const express = require('express');
const app = express();

app.get('/', (req, res) => res.send('Hello from ECS Fargate!'));

app.get('/health', (req, res) => res.json({ status: 'OK' }));

app.get('/error', (req, res) => {
	  const err = [[502,'Bad Request'],[401,'Unauthorized'],[404,'Not Found'],[500,'Server Error'], [403,'Forbidden']]
	    [Math.floor(Math.random() * 5)];

	  res.status(err[0]).json({ error: err[1] });
});

app.listen(3000, () => console.log('ecsapp running on 3000'));
 
